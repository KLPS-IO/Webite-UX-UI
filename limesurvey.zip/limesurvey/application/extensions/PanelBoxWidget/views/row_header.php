<div class="<?php echo $containerclass; ?> ls-flex ls-panelboxes selector__lstour--mainfunctionboxes">
<div class="ls-flex ls-flex-row wrap ls-panelboxes-inner-container <?php echo $orientation; ?> " >
