// Initial definition of Limesurvey javascript object.
// If LS was already defined (e.g. in a plugin), use that object.
var LS = LS || {};

