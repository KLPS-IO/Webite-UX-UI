<?php

class DataSetEquation extends QuestionBaseDataSet
{

}
