<?php

class DataSetMultipleShortText extends QuestionBaseDataSet
{

}
