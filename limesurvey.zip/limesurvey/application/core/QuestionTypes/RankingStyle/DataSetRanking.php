<?php

class DataSetRanking extends QuestionBaseDataSet
{

}
