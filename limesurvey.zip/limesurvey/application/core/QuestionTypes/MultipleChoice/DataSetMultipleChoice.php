<?php

class DataSetMultipleChoice extends QuestionBaseDataSet
{

}
