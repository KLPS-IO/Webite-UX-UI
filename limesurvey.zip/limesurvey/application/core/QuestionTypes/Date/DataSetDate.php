<?php

class DataSetDate extends QuestionBaseDataSet
{

}
