<?php

class DataSetMultipleNumerical extends QuestionBaseDataSet
{

}
