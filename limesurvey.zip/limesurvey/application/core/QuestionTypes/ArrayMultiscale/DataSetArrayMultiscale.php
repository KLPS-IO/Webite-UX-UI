<?php

class DataSetArrayMultiscale extends QuestionBaseDataSet
{

}
