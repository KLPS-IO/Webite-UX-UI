<?php

class DataSetListRadio extends QuestionBaseDataSet
{

}
