<?php

class DataSetArrayYesUncertainNo extends QuestionBaseDataSet
{

}
