<?php

class DataSetArrayFlexibleRow extends QuestionBaseDataSet
{

}
