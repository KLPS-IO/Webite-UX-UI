<?php

class DataSetBoilerplate extends QuestionBaseDataSet
{

}
