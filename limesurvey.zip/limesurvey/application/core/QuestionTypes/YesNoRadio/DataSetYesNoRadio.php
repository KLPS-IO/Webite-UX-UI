<?php

class DataSetYesNoRadio extends QuestionBaseDataSet
{

}
