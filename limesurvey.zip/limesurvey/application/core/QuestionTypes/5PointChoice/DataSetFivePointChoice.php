<?php

class DataSetFivePointChoice extends QuestionBaseDataSet
{

}
