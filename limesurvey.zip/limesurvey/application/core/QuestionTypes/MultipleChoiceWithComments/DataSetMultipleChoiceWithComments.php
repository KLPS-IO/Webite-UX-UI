<?php

class DataSetMultipleChoiceWithComments extends QuestionBaseDataSet
{

}
