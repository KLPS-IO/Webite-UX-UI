<?php

class DataSetArrayMultiFlexText extends QuestionBaseDataSet
{

}
