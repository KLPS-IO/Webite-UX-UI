<?php

namespace LimeSurvey\Exceptions;

use Exception;

/**
 * Used to spit out error messages if mapping attributes doesn't work.
 */
class CPDBException extends Exception
{
}
